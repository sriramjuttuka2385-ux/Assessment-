# Internal Transfers System

## Setup

1. Copy `.env` with your DB credentials
2. Run `go mod tidy`
3. Start server:

```sh
go run cmd/main.go
```

## Endpoints

- POST `/accounts`
- GET `/accounts/{id}`
- POST `/transactions`

## Assumptions

- Same currency for all accounts
- No authentication
