package handlers

import (
    "encoding/json"
    "net/http"
)

func CreateTransactionHandler(w http.ResponseWriter, r *http.Request) {
    w.WriteHeader(http.StatusCreated)
}
