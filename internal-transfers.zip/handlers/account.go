package handlers

import (
    "encoding/json"
    "net/http"
)

func CreateAccountHandler(w http.ResponseWriter, r *http.Request) {
    w.WriteHeader(http.StatusCreated)
}

func GetAccountHandler(w http.ResponseWriter, r *http.Request) {
    w.WriteHeader(http.StatusOK)
}
