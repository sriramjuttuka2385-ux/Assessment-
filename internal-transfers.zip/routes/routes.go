package routes

import (
    "github.com/gorilla/mux"
    "internal-transfers/handlers"
)

func RegisterRoutes(r *mux.Router) {
    r.HandleFunc("/accounts", handlers.CreateAccountHandler).Methods("POST")
    r.HandleFunc("/accounts/{id}", handlers.GetAccountHandler).Methods("GET")
    r.HandleFunc("/transactions", handlers.CreateTransactionHandler).Methods("POST")
}
